BENJI BASKETBALL SPRITE IMPLEMENTATION NOTES FOR GROK
====================================================

Goal
----
Implement these Benji basketball pose sprites into the game as transparent full-body character assets. The basketball must remain a separate game object/sprite, just like the fishing rod setup.

Included Assets
---------------
BLACK / SACKROW BALLERS SET
1. benji_s_sackrow_ballers_defensive_stance.png
2. benji_s_dynamic_basketball_drive.png
3. sackrow_ballers_celebration_pose.png
4. benji_s_midair_jump_shot_follow_through.png
5. benji_sackrow_ballers_action_sprite_sheet.png   (reference sheet)
6. image_set_black_turnaround.png                  (source turnaround reference)

BLUE / 901 DAY SET
7. benji_s_sackreligious_defensive_stance.png
8. dynamic_blue_jersey_runner_sticker.png
9. benji_s_midair_basketball_follow_through.png
10. benji_s_901_day_jump_shot.png
11. benji_basketball_action_sprite_sheet.png       (reference sheet)
12. image_set_blue_turnaround.png                  (source turnaround reference)

Recommended Role For Each Pose
------------------------------
For BOTH outfit sets, use the same gameplay mapping:

A. Defensive stance
   - Use as: ready / idle / defensive movement pose
   - Files:
     * benji_s_sackrow_ballers_defensive_stance.png
     * benji_s_sackreligious_defensive_stance.png

B. Running / drive pose
   - Use as: movement, sprint, slash, fast break, dribble drive base pose
   - Files:
     * benji_s_dynamic_basketball_drive.png
     * dynamic_blue_jersey_runner_sticker.png
   - If needed, flip horizontally for left/right travel.

C. Front shooting / celebration follow-through pose
   - Use as: jump shot finish, made-shot celebration, emote
   - Files:
     * sackrow_ballers_celebration_pose.png
     * benji_s_midair_basketball_follow_through.png

D. Back shooting pose
   - Use as: rear camera jump-shot finish / under-rim / away-from-camera shot
   - Files:
     * benji_s_midair_jump_shot_follow_through.png
     * benji_s_901_day_jump_shot.png

Important Implementation Rules
------------------------------
1. Keep all sprites FULL BODY.
   - Do not crop the head, feet, hands, or legs.
   - The full silhouette must remain visible on screen.

2. Preserve consistent scale.
   - Every Benji sprite should be resized to the same world scale.
   - Head size, torso size, and shoe size should visually match across all outfits.
   - The outfit changes, but character proportions must stay the same.

3. Use transparent PNGs only.
   - No black rectangle backgrounds.
   - Import as alpha-enabled textures/sprites.

4. Use a shared pivot/origin.
   - Set origin/pivot to bottom-center at the midpoint between the feet.
   - This keeps positioning stable when swapping outfits or poses.

5. Keep a consistent render box.
   - Normalize all sprites to the same canvas size if your engine supports it.
   - Add transparent padding if needed instead of scaling some frames differently.
   - This prevents floating, sinking, or popping during animation/state changes.

6. Ball must be separate.
   - Do NOT bake the ball into the player sprite.
   - Spawn / attach a separate basketball object.
   - For dribble: attach the ball near the lead hand and animate bounce independently.
   - For shot gather: attach the ball near chest or shooting pocket.
   - At release: detach ball from hand and animate its flight separately.

7. Layering order.
   - Shadow layer at bottom.
   - Player sprite above court.
   - Ball sprite above or in front of player only when needed.
   - UI always above gameplay.

Suggested State Machine
-----------------------
Use the same state names for both outfits.

idle / ready
  -> defensive stance sprite

move / run
  -> running-drive sprite

shoot_front
  -> front follow-through sprite

shoot_back
  -> back follow-through sprite

celebrate
  -> front follow-through / celebration sprite

If you want smoother animation later, these can act as key poses.

Suggested File-to-State Mapping
-------------------------------
BLACK OUTFIT
- idle_black = benji_s_sackrow_ballers_defensive_stance.png
- run_black = benji_s_dynamic_basketball_drive.png
- shoot_front_black = sackrow_ballers_celebration_pose.png
- shoot_back_black = benji_s_midair_jump_shot_follow_through.png

BLUE 901 DAY OUTFIT
- idle_blue = benji_s_sackreligious_defensive_stance.png
- run_blue = dynamic_blue_jersey_runner_sticker.png
- shoot_front_blue = benji_s_midair_basketball_follow_through.png
- shoot_back_blue = benji_s_901_day_jump_shot.png

Outfit Switching
----------------
Set up outfit switching by keeping the exact same state names and swapping only the underlying sprite files.

Example:
currentOutfit = "black" or "blue"
state = "idle", "run", "shoot_front", "shoot_back"

Then load:
sprite = spriteMap[currentOutfit][state]

This way, no gameplay logic changes when the outfit changes.

Ball Attachment Suggestions
---------------------------
Use invisible anchor points or hard-coded offsets relative to the player:

For run/dribble pose:
- Anchor the ball near the forward hand side.
- Bounce the ball from hand height to near knee/shin height.

For front shooting pose:
- Pre-release: ball near the shooting hand.
- Post-release: hide attached ball and launch separate projectile.

For back shooting pose:
- Start ball above the head / hands.
- Then release into independent projectile arc.

Collision / Hitbox Suggestions
------------------------------
Use a simpler collision body than the sprite silhouette:
- Width: around 55% to 60% of visible sprite width
- Height: around 80% to 85% of visible sprite height
- Anchor from lower torso to shoes
This avoids oversized collision from arms and cap brim.

Depth / Sorting Suggestions
---------------------------
If the court uses top-down or pseudo-3D sorting:
- Sort by the Y position of the feet, not the top of the image.
- The feet should determine grounding.

What To Avoid
-------------
- No head-only crops
- No torso-only crops
- No missing legs or cut-off shoes
- No different scaling between outfits
- No black background blocks behind the sprites
- No ball merged into the player PNG
- No changing Benji's face, body proportions, or wardrobe details during import

Recommended Pack Structure
--------------------------
/benji_basketball_assets/
  /black_set/
    benji_s_sackrow_ballers_defensive_stance.png
    benji_s_dynamic_basketball_drive.png
    sackrow_ballers_celebration_pose.png
    benji_s_midair_jump_shot_follow_through.png
    benji_sackrow_ballers_action_sprite_sheet.png
    image_set_black_turnaround.png
  /blue_901_set/
    benji_s_sackreligious_defensive_stance.png
    dynamic_blue_jersey_runner_sticker.png
    benji_s_midair_basketball_follow_through.png
    benji_s_901_day_jump_shot.png
    benji_basketball_action_sprite_sheet.png
    image_set_blue_turnaround.png
  README_GROK_IMPLEMENTATION.txt

Short Prompt You Can Paste To Grok
----------------------------------
Implement these Benji basketball PNGs as full-body transparent sprites. Preserve exact character proportions and outfit details. Use the defensive stance as idle, the running pose as movement, the front follow-through as front shot/celebration, and the rear follow-through as back-view shot. Keep a bottom-center pivot between the feet for every sprite and normalize all sprites to a consistent render box so scale does not change when swapping states or outfits. The basketball must be a separate sprite/object, not baked into the character, with attach points for dribble, gather, and release. Prevent any cropping issues: no head-only, torso-only, or missing-leg renders. Use the feet Y-position for ground alignment and depth sorting.
